// Scope browser form-history suppression to this app, never the host website.
(() => {
  const root=document.getElementById('nai-media-host')?.shadowRoot ||
    (document.documentElement.dataset.localDuplicateReview==='1'?document:null);
  if(!root||root.__noSavedFormInfo)return;
  root.__noSavedFormInfo=true;
  const selector='input,textarea,form';
  function apply(node){
    if(node.nodeType===1&&node.matches(selector))node.setAttribute('autocomplete','off');
    node.querySelectorAll?.(selector).forEach(el=>el.setAttribute('autocomplete','off'));
  }
  apply(root);
  new MutationObserver(records=>{for(const record of records)for(const node of record.addedNodes)apply(node)}).observe(root,{childList:true,subtree:true});
  root.addEventListener('focusin',event=>{if(event.target.matches?.(selector))event.target.setAttribute('autocomplete','off')},true);
})();

// Clear only search/filter inputs; names, profile fields and editable metadata stay plain.
(()=>{
const root=document.getElementById('nai-media-host')?.shadowRoot||(document.documentElement.dataset.localDuplicateReview==='1'?document:null);if(!root||root.__clearSearch)return;root.__clearSearch=true;
const style=document.createElement('style');style.textContent='.naiSearchField{display:inline-flex;position:relative;align-items:center;min-width:0;vertical-align:middle}.naiSearchField>input{width:100%!important;min-width:0!important;flex:1!important;padding-right:32px!important;box-sizing:border-box}.naiSearchField>button.naiSearchClear{position:absolute!important;right:3px!important;top:50%!important;transform:translateY(-50%);width:26px!important;height:26px!important;min-height:0!important;padding:0!important;margin:0!important;line-height:24px!important;font:20px system-ui!important;border:0!important;background:transparent!important;color:inherit!important;cursor:pointer;z-index:1}.naiSearchField>button[hidden]{display:none!important}.naiSearchField input::-webkit-search-cancel-button{display:none}';(root.head||root).append(style);
function enhance(input){if(!(input instanceof HTMLInputElement)||!['text','search'].includes(input.type)||input.parentElement?.classList.contains('naiSearchField'))return;const label=[input.id,input.placeholder,input.getAttribute('aria-label')].join(' ');if(input.type!=='search'&&!/search|filter/i.test(label))return;
 const field=document.createElement('span'),button=document.createElement('button'),css=getComputedStyle(input);field.className='naiSearchField';field.style.flex=css.flexGrow!=='0'?css.flex:'1 1 160px';if(input.style.width)field.style.width=input.style.width;button.className='naiSearchClear';button.type='button';button.textContent='×';button.title='Clear search';button.setAttribute('aria-label','Clear search');input.before(field);field.append(input,button);const sync=()=>{button.hidden=!input.value;button.disabled=input.disabled};input.addEventListener('input',sync);input.addEventListener('focus',sync);button.onclick=e=>{e.preventDefault();e.stopPropagation();input.value='';input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));sync();input.focus()};sync();}
root.addEventListener('input',e=>{const input=e.target,button=input.parentElement?.querySelector('.naiSearchClear');if(button){button.hidden=!input.value;button.disabled=input.disabled}},true);
function scan(node){if(node.nodeType===1&&node.matches('input'))enhance(node);node.querySelectorAll?.('input').forEach(enhance)}scan(root);new MutationObserver(records=>{for(const record of records)for(const node of record.addedNodes)if(node.isConnected)scan(node)}).observe(root,{childList:true,subtree:true});
})();
