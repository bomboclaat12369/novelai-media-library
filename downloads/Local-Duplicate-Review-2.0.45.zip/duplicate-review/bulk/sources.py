"""Source identity is independent of batch folders, dates and quarantine move IDs."""
import re
from pathlib import PureWindowsPath, PurePosixPath

POST = re.compile(r'(?:^|\s)Post\s+(\d+)(?:\s|$)', re.I)
SHORTCODE = re.compile(r'^[A-Za-z0-9_-]{8,32}$')
QUARANTINE = '_Duplicate_Review_Quarantine'
DATED_IG_POST = re.compile(r'^(\d{4}-\d{2}-\d{2}) - Post ([A-Za-z0-9_-]{8,32})$', re.I)
IG_ACCOUNT_FOLDER = re.compile(r'^Instagram[-_ ]+([A-Za-z0-9_.-]+)$', re.I)


def natural(value):
    return tuple((1,int(x)) if x.isdigit() else (0,x.casefold()) for x in re.split(r'(\d+)',str(value)))


def original_order_key(name, source):
    if str(source).startswith('instagram:'):
        match = re.search(r'(?:^|_)(\d+)\.[^.]+$', name)
        if match:
            return (0,int(match[1]),natural(name))
    return (1,0,natural(name))


def original_name(item, source):
    paths = [o.get('original_path') or o.get('path','') for o in item.get('origins',[]) if o.get('key')==source]
    names = [re.split(r'[\\/]',path)[-1] for path in paths if path]
    return min(names,key=lambda name:original_order_key(name,source)) if names else re.split(r'[\\/]',item['path'])[-1]


def original_sequence(catalog, source, ids):
    return sorted(ids,key=lambda i:(original_order_key(original_name(catalog[i],source),source),i))


def source_of(path, forum='smg', owner=''):
    parts = list((PureWindowsPath(path) if '\\' in str(path) else PurePosixPath(path)).parts)
    quarantine = next((i for i, p in enumerate(parts) if p.casefold() == QUARANTINE.casefold()), None)
    if quarantine is not None:
        # Only strip the quarantine wrapper. Keep the original ancestry intact.
        parts = parts[:quarantine] + parts[quarantine + 2:]
    original = str((PureWindowsPath if '\\' in str(path) else PurePosixPath)(*parts))
    locations = {'original_path': original, 'quarantine_path': str(path)} if quarantine is not None else {}
    parent = parts[:-1]
    # Dated gallery-dl posts directly under an explicitly named Instagram folder.
    # Numeric forum post IDs are deliberately left to the existing forum parser.
    for i in range(len(parent)-1, 0, -1):
        post = DATED_IG_POST.fullmatch(parent[i])
        account = IG_ACCOUNT_FOLDER.fullmatch(parent[i-1])
        if post and account and not post[2].isdigit():
            user, shortcode = account[1], post[2]
            return {'key': 'instagram:' + user.casefold() + ':' + shortcode,
                    'kind': 'instagram', 'label': post[1] + ' · ' + user + ' / ' + shortcode,
                    'post_id': shortcode, 'post_date': post[1],
                    'path': str(path), 'quarantine': quarantine is not None, **locations}
    for part in reversed(parent):
        match = POST.search(part)
        if match:
            return {'key': 'forum:' + forum.strip().casefold() + ':' + match[1],
                    'kind': 'forum', 'label': part, 'post_id': match[1],
                    'path': str(path), 'quarantine': quarantine is not None, **locations}
    for i, part in enumerate(parent):
        if re.search(r'(?:^|[\s_-])(ig|instagram)(?:$|[\s_-])', part, re.I) and i + 2 < len(parent):
            user, post = parent[i+1:i+3]
            if SHORTCODE.fullmatch(post):
                return {'key': 'instagram:' + user.casefold() + ':' + post,
                        'kind': 'instagram', 'label': user + ' / ' + post,
                        'post_id': post, 'path': str(path), 'quarantine': quarantine is not None, **locations}
    # Unknown folders remain auditable but receive NO same-post boost.
    return {'key': 'folder:' + owner + ':' + '/'.join(parent).casefold(), 'kind': 'folder',
            'label': parent[-1] if parent else 'Unknown source', 'post_id': None,
            'path': str(path), 'quarantine': quarantine is not None, **locations}
